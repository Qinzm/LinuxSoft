#! /bin/bash
#
rm -f $MYSQLTEST_VARDIR/master-data/test/rpl_misc_functions.outfile
